import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:radar/constants/colors.dart';
import 'package:radar/constants/route_arguments.dart';
import 'package:radar/constants/router.dart';
import 'package:radar/constants/size_config.dart';
import 'package:radar/domain/entities/scan_qr_code/Scan_qr_code_payload.dart';
import 'package:radar/main.dart';
import 'package:radar/presentation/cubits/scan_qr_code/scan_qrcode_cubit.dart';
import 'package:radar/presentation/widgets/button_widget.dart';

import 'package:radar/presentation/widgets/radius_text_field.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:simple_barcode_scanner/simple_barcode_scanner.dart';
import 'package:easy_localization/easy_localization.dart';
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key,  this.isBack=false});
final bool isBack;
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String email = "";
  String name = "";
  late ScanQrCodeCubit scanQrcodeCubit;

  String image="";
  String? roleName;
  void showDeleteConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: GlobalColors.backgroundColor,
          title: Text('Delete Account'.tr(),style: TextStyle(
            color: Colors.white,
            fontSize: SizeConfig.width(context, 0.03),
          )),
          content: Text('Are you sure you want to delete this account?'.tr(),style: TextStyle(
            color: Colors.white,
            fontSize: SizeConfig.width(context, 0.03),
          )),
          actions: <Widget>[
           TextButton(
              child: Text('Cancel'.tr(),style: TextStyle(
                color: Colors.white,
                fontSize: SizeConfig.width(context, 0.03),
              )),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
              },
            ),
            TextButton(
              child: Text('Delete',style: TextStyle(
                color: Colors.white,
                fontSize: SizeConfig.width(context, 0.03),
              )),
              onPressed: ()async {
                // Add your account deletion logic here
           // Dismiss the dialog
                Navigator.pushNamedAndRemoveUntil(context, AppRoutes.loginScreenRoute, (route) => false);
                SharedPreferences prefs =
                    await SharedPreferences.getInstance();
                prefs.clear();

              },
            ),
          ],
        );
      },
    );
  }

  Future getUserDetailsFromLocal() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    roleName = prefs.getString(
      "role_name",
    ) ??
        "";
    image = prefs.getString(
          "user_image",
        ) ??
        "";
    name = prefs.getString(
          "user_name",
        ) ??
        "";
    email = prefs.getString(
          "user_email",
        ) ??
        "Someone";
    print("role name profile screen ${roleName}");
    setState(() {});
  }

  @override
  void initState() {
    getUserDetailsFromLocal();
    scanQrcodeCubit = BlocProvider.of<ScanQrCodeCubit>(context);
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        elevation: 0,
        automaticallyImplyLeading: false,
        backgroundColor: Colors.black,
        //GlobalColors.backgroundColor,
        centerTitle: true,
        /*actions: [
          IconButton(
            onPressed: () {
              //  Navigator.pop(context);
            },
            icon: Image.asset("assets/icons/message_icon.png",
                width: SizeConfig.width(context, 0.05)),
            color: Colors.white,
          ),
          IconButton(
            onPressed: () {
              //  Navigator.pop(context);
            },
            icon: Padding(
              padding: EdgeInsets.only(right: SizeConfig.width(context, 0.05)),
              child: Image.asset("assets/icons/notification.png",
                  width: SizeConfig.width(context, 0.05)),
            ),
            color: Colors.white,
          ),
        ],*/
         leading: (widget.isBack)?
         IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Padding(
            padding: EdgeInsets.only(left: SizeConfig.width(context, 0.05),right:  SizeConfig.width(context, 0.05)),
            child: Icon(
              Icons.arrow_back_ios,
              size: SizeConfig.width(context, 0.05),
            ),
          ),
          color: Colors.white,
        ):Container(),
        title: Text(
          "Profile".tr(),
          style: TextStyle(
            color: GlobalColors.whiteColor,
            fontSize: SizeConfig.width(context, 0.05),
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: SizeConfig.height(context, 0.04),
                ),
                Container(
                //  height: SizeConfig.height(context, 0.2),
                  width: SizeConfig.width(context, 0.9),
                  decoration: BoxDecoration(
                      color: GlobalColors.backgroundColor,
                      borderRadius: BorderRadius.circular(
                        SizeConfig.width(context, 0.02),
                      )),
                  padding: EdgeInsets.only(
                    top: SizeConfig.height(context, 0.02),
                    bottom: SizeConfig.height(context, 0.02),
                    left: SizeConfig.width(context, 0.04),
                    right: SizeConfig.width(context, 0.04),
                  ),
                  margin: EdgeInsets.only(
                      left: SizeConfig.width(context, 0.05),
                      right: SizeConfig.width(context, 0.05)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      (image.contains("http"))
                          ? CircleAvatar(
                              backgroundImage:
                                  NetworkImage(image),
                              //                backgroundColor: Colors.red,
                              radius: SizeConfig.width(context, 0.11),
                            )
                          : CircleAvatar(
                              backgroundImage:
                                  AssetImage("assets/icons/profile_icon.png"),
                              //                backgroundColor: Colors.red,
                              radius: SizeConfig.width(context, 0.11),
                            ),
                      SizedBox(height: SizeConfig.height(context, 0.01),),
                      Text(
                        name,
                        style: TextStyle(
                          color: GlobalColors.whiteColor,
                          fontWeight: FontWeight.w500,
                          fontSize: SizeConfig.width(context, 0.04),
                        ),
                      ),
                      Text(
                        email,
                        style: TextStyle(
                          color: GlobalColors.whiteColor,
                          fontWeight: FontWeight.w300,
                          fontSize: SizeConfig.width(context, 0.03),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    Navigator.pushNamed(
                        context, AppRoutes.editProfileScreenRoute,arguments: EditProfileScreenArgs(isFromLogin: false,phoneCode: "+92"));
                  },
                  child: Text(
                    'Edit Profile'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),

                ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    showDeleteConfirmationDialog(context);
                 //   Navigator.pushNamed(context, AppRoutes.qrAttandance);
                  },
                  child: Text(
                    'Delete Account '.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),

                (roleName=="Client")?Container(): SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                (roleName=="Client")?Container(): ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    Navigator.pushNamed(context, AppRoutes.qrCodeScreenRoute);
                  },
                  child: Text(
                    'Qr Code'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    Navigator.pushNamed(
                        context, AppRoutes.notificationSettingScreenRoute);
                  },
                  child: Text(
                    'Notification Settings'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ), ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return StatefulBuilder(builder: (context, setState) {
                            return AlertDialog(
                              backgroundColor: GlobalColors.backgroundColor,
                              title: Center(child: Text('Change Language'.tr(),style: TextStyle(color: Colors.white),)),
                              content: SizedBox(
                                height: SizeConfig.height(context, 0.15),
                                child: Column(
                                  children: [
                                    ElevatedButton(
                                        onPressed: () async {
                                          SharedPreferences prefs = await SharedPreferences.getInstance();
                                          prefs.setBool("isEnglish", true);
                                          await (context.setLocale(Locale('en')));

                                          Navigator.of(context).pop();
                                        },
                                        child: const Text('English')),
                                    ElevatedButton(
                                      onPressed: () async {
                                        SharedPreferences prefs = await SharedPreferences.getInstance();
                                        prefs.setBool("isEnglish", false);
                                        await (context.setLocale(Locale('ar')));
                                        Navigator.of(context).pop();
                                      },
                                      child: const Text('عربي'),
                                    )
                                  ],
                                ),
                              ),
                            );
                          });
                        });
                  },
                  child: Text(
                    'Languages'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    Navigator.pushNamed(
                        context, AppRoutes.changePasswordScreenRoute);
                  },
                  child: Text(
                    'Change Password'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                ProfileButton(
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    Navigator.pushNamed(context, AppRoutes.complainScreenRoute);
                  },
                  child: Text(
                    'Complain to Supervisor'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
                ProfileButton(
                  gradientFirstColor: GlobalColors.logoutColor,
                  //    width: SizeConfig.width(context, 0.5),
                  onPressed: () async {
                    SharedPreferences prefs =
                    await SharedPreferences.getInstance();
                    prefs.remove("qr_code");
                    prefs.clear();
                    prefs.setBool("isLocationDailog", true);
                    socket.disconnect();
                    Navigator.pushNamedAndRemoveUntil(
                        context, AppRoutes.loginScreenRoute, (route) => false);


                  },
                  child: Text(
                    'Logout'.tr(),
                    // textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: SizeConfig.width(context, 0.04),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.height(context, 0.02),
                ),
              ],
            ),
            BlocConsumer<ScanQrCodeCubit, ScanQrCodeState>(
                builder: (context, state) {
              if (state is ScanQrcodeLoading) {
                return Align(
                  alignment: Alignment.center,
                  child: Container(
                    height: SizeConfig.height(context, 0.5),
                    child: Center(
                      child: CircularProgressIndicator(
                        color: Colors.white,
                      ),
                    ),
                  ),
                );
              }
              return Container();
            }, listener: (context, state) {
              if (state is ScanQrcodeFailure) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(state.errorMessage),
                  ),
                );
              }
              if (state is ScanQrcodeSuccess) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Attandance Marked SuccessFully".tr()),
                  ),
                );
              }
            }),
          ],
        ),
      ),
    );
  }
}
