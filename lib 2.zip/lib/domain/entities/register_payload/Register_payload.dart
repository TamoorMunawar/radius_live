/// name : "aa"
/// email : "emaq@gmail.com"
/// password : 12345678
/// gender : "male"
/// country_phonecode : "+92"
/// mobile : "3212444600"
/// country_id : "2"
/// date_of_birth : "16-05-1998"
/// about_me : "sdfsdfsdf"
/// image : "3212444600"

class RegisterPayload {
  RegisterPayload({
      this.name, 
      this.iqamaId,
      this.email,
      this.password, 
      this.gender, 
      this.countryPhonecode, 
      this.mobile, 
      this.whatsappCountryCode,
      this.age,
      this.countryId,
      this.iqamaExpiry,
      this.dateOfBirth,
      this.aboutMe, 
      this.deviceToken,
      this.whatsappNumber,
      this.city,
      this.image,});

  RegisterPayload.fromJson(dynamic json) {
    name = json['name'];
    email = json['email'];
    password = json['password'];
    gender = json['gender'];
    countryPhonecode = json['country_phonecode'];
    mobile = json['mobile'];
    countryId = json['country_id'];
    dateOfBirth = json['date_of_birth'];
    aboutMe = json['about_me'];
    image = json['image'];
  }
  String? iqamaId;
  String? name;
  String? email;
  String? whatsappCountryCode;
  String? password;
  String? gender;
  String? countryPhonecode;
  String? mobile;
  String? countryId;
  String? dateOfBirth;
  String? whatsappNumber;
  String? age;
  String? aboutMe;
  String? iqamaExpiry;
  String? image;
  String? deviceToken;
  String? city;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = name;
    map['iqama_id'] = iqamaId;
    map['city'] = city;
    map['device_token'] = deviceToken;
    map['iqama_expiry'] = iqamaExpiry;
    map['email'] = email;
    map['whatsapp_number_country_code'] = whatsappCountryCode;
    map['password'] = password;
    map['gender'] = gender;
    map['country_phonecode'] = countryPhonecode;
    map['mobile'] = mobile;
    map['country_id'] = countryId;
    map['date_of_birth'] = dateOfBirth;
    map['about_me'] = aboutMe;
    map['image'] = image;
    map['age'] = age;
    map['WhatsApp_number'] = whatsappNumber;
    return map;
  }

}