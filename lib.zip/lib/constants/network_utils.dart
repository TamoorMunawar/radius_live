class NetworkUtils {
   static String baseUrl = 'https://dashboard.radiusapp.online/api/v1';

   static Map<String, String> headers = <String, String>{
      "Content-Type": "application/json",
   };
}
