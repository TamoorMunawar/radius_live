
class ConstantImage{
  static const String localBackGroundImage = "assets/new_onboarding_main/onboarding_main.png";
  static const String logo = "assets/new_onboarding_main/LOGO.png";
  static const String gifLogo = "assets/new_onboarding_main/steprowks_feedback_wave_final_mobile.gif";
  static const String ftslogo = "assets/new_onboarding_main/fts_appbar_logo.png";
  static const String iconbg = "assets/new_onboarding_main/bg.png"; // Background image

}