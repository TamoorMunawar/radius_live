import 'package:flutter/material.dart';
import 'package:radar/constants/colors.dart';
import 'package:radar/constants/size_config.dart';

class SubmitButton extends StatelessWidget {
  SubmitButton(
      {super.key,
      this.width,
      this.height,
      this.gradientFirstColor,
      this.gradientSecondColor,
      this.borderWidth,
      required this.onPressed,
      required this.child});

  final double? width;
  final double? height;
  final Color? gradientFirstColor;
  final Color? gradientSecondColor;
  final double? borderWidth;
  final VoidCallback? onPressed;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: width ?? SizeConfig.width(context, 0.85),
        height: height ?? SizeConfig.height(context, 0.07),
        decoration: ShapeDecoration(
          color:gradientFirstColor?? GlobalColors.submitButtonColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
                borderWidth ?? SizeConfig.width(context, 0.025)),
          ),
        ),
        child: Center(child: child),
      ),
    );
  }
}
class ProfileButton extends StatelessWidget {
  ProfileButton(
      {super.key,
      this.width,
      this.height,
      this.gradientFirstColor,
      this.gradientSecondColor,
      this.borderWidth,
      required this.onPressed,
      required this.child});

  final double? width;
  final double? height;
  final Color? gradientFirstColor;
  final Color? gradientSecondColor;
  final double? borderWidth;
  final VoidCallback? onPressed;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Center(
        child: Container(
          padding: EdgeInsets.only(
            top: SizeConfig.height(context, 0.02),
            bottom: SizeConfig.height(context, 0.02),
            left: SizeConfig.width(context, 0.04),
            right: SizeConfig.width(context, 0.04),
          ),
          margin: EdgeInsets.only(
              left: SizeConfig.width(context, 0.05),
              right: SizeConfig.width(context, 0.05)),
          width: width ?? SizeConfig.width(context, 0.9),
    //      height: height ?? SizeConfig.height(context, 0.08),
          decoration: ShapeDecoration(
            color: gradientFirstColor??GlobalColors.profileButtonColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(
                  borderWidth ?? SizeConfig.width(context, 0.025)),
            ),
          ),
            //    alignment: Alignment.centerLeft,
          child: child,
        ),
      ),
    );
  }
}
