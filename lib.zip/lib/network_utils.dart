class NetworkUtils {

  static String baseUrl = 'https://worksuite.dev/api/v1/';

}


